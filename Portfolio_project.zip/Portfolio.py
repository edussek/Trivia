import prizes_portfolio

User = input("Enter name: ")

print(f"Welcome {User}")

user_points = 0


Q1 = input("What franchise is the best North American franchise money can buy? ")
if Q1 == "New York Yankees":
    user_points += 1
    print("Correct")
    

else:
    print("Incorrect")

Q2 = input("As of the 2023 MLB All-Star break, what team is last place in the AL East? ")
if Q2 == "red sox":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q3 = input("Which school has the best colors and the best stadium in college football? ")
if Q3 == "University of Florida":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q4 = input("Which MLB team belongs in the minors? ")
if Q4 == "Oakland AAA's":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q5 = input("What is it not all about in college football? ")
if Q5 == "The U":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q6 = input("What NBA team was projected to win multiple titles and take over NYC on a permanent basis but ended up winning nothing? ")
if Q6 == "Brooklyn Nets":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q7 = input("What batting average is the Mendoza line? ")
if Q7 == ".200":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q8 = input("Which college football conference is considered the unquestioned best conference? ")
if Q8 == "SEC":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q9 = input("True or False. Baseball's analytics factors in emotion. ")
if Q9 == "False":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q10 = input("What's the name of the football stadium Florida State plays in? ")
if Q10 == "Ron Zook Field":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q11 = input("What was the patroits' 'dynasty' built on? ")
if Q11 == "The Tuck Rule":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q12 = input("Which American football team has the acronym for just end the season? ")
if Q12 == "New York Jets":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q13 = input("Dating back to 2011, who gets paid approximately $1.19 million dollars every July 1st until 2035 despite not playing a game for the Mets since 1999? ")
if Q13 == "Bobby Bonilla":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q14 = input("In the 2007 season, the patriots won 18 games but don't have a Lombardi to show for it. Why is that the case? ")
if Q14 == "New York Football Giants":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q15 = input("Which school was known for free shoes in the 90s? ")
if Q15 == "Florida State":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q16 = input("What fraudulent NFL head coach was considered by Chris Johnson as a brilliant offensive mind? ")
if Q16 == "Adam Gase":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q17 = input("What NFL QB ran into an offensive lineman's backside on a nationally televised game on Thanksgiving night? ")
if Q17 == "Mark Sanchez":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q18 = input("Which US state is the lone state that only offers full service gas? ")
if Q18 == "New Jersey":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q19 = input("This meat was first created in NJ. ")
if Q19 == "Taylor Ham":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q20 = input("What major American sporting event was hosted in NJ (not NY)? ")
if Q20 == "Super bowl 48":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

Q21 = input("Who created Python Programming? ")
if Q21 == "Guido Van Rossum":
    user_points += 1
    print("Correct")
    
else:
    print("Incorrect")

total_points = 1 * (user_points)
print(total_points)

if total_points > 0 and total_points <= 5:
    print(f"{User} wins {prizes_portfolio.Prize_1}")

elif total_points > 5 and total_points <= 10:
    print(f"{User} wins {prizes_portfolio.Prize_2}")

elif total_points > 10 and total_points <= 15:
    print(f"{User} wins {prizes_portfolio.Prize_3}")

elif total_points > 15 and total_points <= 20:
    print(f"{User} wins {prizes_portfolio.Prize_4}")

elif total_points == 21:
    print(f"{User} wins {prizes_portfolio.Prize_5}")

else:
    print(f"{User} wins {prizes_portfolio.Prize_0}")