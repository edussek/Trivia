class Prize_0:
    def __init__(self, brown_paper_bag):
        self.brown_paper_bag = brown_paper_bag

class Prize_1(Prize_0):
    def __init__(self, mattel_car):
        self.mattel = mattel_car

class Prize_2(Prize_0):
    def __init__(self, big_wheel):
        self.big_wheel = big_wheel

class Prize_3(Prize_0):
    def __init__(self, auto_bike):
        self.auto_bike = auto_bike

class Prize_4(Prize_0):
    def __init__(self, F150_with_50hp):
       self.F150_with_50hp = F150_with_50hp

class Prize_5(Prize_0):
     def __init__(self, real_F150):
         self.real_F150 = real_F150